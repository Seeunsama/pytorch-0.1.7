#ifndef THP_SERIALIZATION_INC
#define THP_SERIALIZATION_INC

#include "generic/serialization.h"
#include <TH/THGenerateAllTypes.h>

#endif

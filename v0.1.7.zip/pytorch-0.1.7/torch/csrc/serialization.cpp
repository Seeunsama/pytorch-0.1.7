#include <Python.h>
#include <system_error>

#include "THP.h"

#include "generic/serialization.cpp"
#include <TH/THGenerateAllTypes.h>

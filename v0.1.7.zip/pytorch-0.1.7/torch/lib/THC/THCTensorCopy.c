#include "THCTensorCopy.h"
#include "THCCachingHostAllocator.h"

#include "generic/THCTensorCopy.c"
#include "THCGenerateAllTypes.h"
